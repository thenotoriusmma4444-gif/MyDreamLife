package com.mydreamlife.app

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Sun = Color(0xFFF2C94C)
private val Gold = Color(0xFFD6A63B)
private val Cream = Color(0xFFFFF4D6)
private val Ink = Color(0xFF29251D)
private val Muted = Color(0xFF817866)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyDreamLifeApp() }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    Home("Главная", Icons.Rounded.Home), Practices("Практики", Icons.Rounded.SelfImprovement),
    Notebook("Блокнот", Icons.Rounded.EditNote), Dreams("Мои мечты", Icons.Rounded.AutoAwesome), Profile("Профиль", Icons.Rounded.Person)
}

private data class Note(val text: String, val date: String)
private data class Dream(val title: String, val detail: String, val progress: Int)

private class LocalStore(context: Context) {
    private val p = context.getSharedPreferences("my_dream_life", Context.MODE_PRIVATE)
    fun int(key: String, default: Int = 0) = p.getInt(key, default)
    fun bool(key: String, default: Boolean = false) = p.getBoolean(key, default)
    fun string(key: String, default: String = "") = p.getString(key, default) ?: default
    fun putInt(key: String, value: Int) = p.edit().putInt(key, value).apply()
    fun putBool(key: String, value: Boolean) = p.edit().putBoolean(key, value).apply()
    fun putString(key: String, value: String) = p.edit().putString(key, value).apply()
    fun notes(): List<Note> = runCatching {
        val a = JSONArray(string("notes", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); Note(o.getString("text"), o.getString("date")) }
    }.getOrDefault(emptyList())
    fun saveNotes(items: List<Note>) { val a = JSONArray(); items.forEach { a.put(org.json.JSONObject().put("text", it.text).put("date", it.date)) }; putString("notes", a.toString()) }
    fun dreams(): List<Dream> = runCatching {
        val a = JSONArray(string("dreams", "[]")); (0 until a.length()).map { val o = a.getJSONObject(it); Dream(o.getString("title"), o.optString("detail"), o.optInt("progress")) }
    }.getOrDefault(emptyList())
    fun saveDreams(items: List<Dream>) { val a = JSONArray(); items.forEach { a.put(org.json.JSONObject().put("title", it.title).put("detail", it.detail).put("progress", it.progress)) }; putString("dreams", a.toString()) }
}

@Composable
private fun MyDreamLifeApp() {
    val context = LocalContext.current
    val store = remember { LocalStore(context) }
    var selected by remember { mutableStateOf(Tab.Home) }
    var xp by remember { mutableIntStateOf(store.int("xp")) }
    var done by remember { mutableStateOf(store.bool("practice_done")) }
    var done2 by remember { mutableStateOf(store.bool("practice_done2")) }
    var notes by remember { mutableStateOf(store.notes()) }
    var dreams by remember { mutableStateOf(store.dreams()) }
    var dark = isSystemInDarkTheme()
    val background = if (dark) Color(0xFF191813) else Color(0xFFFFFBF2)
    val surface = if (dark) Color(0xFF28251E) else Color.White
    val ink = if (dark) Color(0xFFFFF8E8) else Ink
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = Sun, secondary = Gold, background = background, surface = surface, onSurface = ink) else lightColorScheme(primary = Sun, secondary = Gold, background = background, surface = surface, onSurface = ink)) {
        Scaffold(containerColor = background, bottomBar = {
            NavigationBar(containerColor = surface, tonalElevation = 8.dp) {
                Tab.entries.forEach { tab -> NavigationBarItem(selected == tab, { selected = tab }, icon = { Icon(tab.icon, tab.label) }, label = { Text(tab.label, fontSize = 9.sp) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, indicatorColor = Sun.copy(alpha = .35f))) }
            }
        }) { padding ->
            AnimatedContent(selected, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "tabs", modifier = Modifier.padding(padding)) { tab ->
                when (tab) {
                    Tab.Home -> HomeScreen(surface, ink, xp, done, done2, { done = !done; store.putBool("practice_done", done); if (done && !store.bool("practice1_xp_claimed")) { xp += 10; store.putInt("xp", xp); store.putBool("practice1_xp_claimed", true) } }, { done2 = !done2; store.putBool("practice_done2", done2); if (done2 && !store.bool("practice2_xp_claimed")) { xp += 10; store.putInt("xp", xp); store.putBool("practice2_xp_claimed", true) } }, { selected = Tab.Practices })
                    Tab.Practices -> PracticesScreen(surface, ink, store)
                    Tab.Notebook -> NotebookScreen(surface, ink, notes) { notes = it; store.saveNotes(it) }
                    Tab.Dreams -> DreamsScreen(surface, ink, dreams) { dreams = it; store.saveDreams(it) }
                    Tab.Profile -> ProfileScreen(surface, ink, xp, notes.size, dreams.size, store)
                }
            }
        }
    }
}

@Composable private fun Page(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Column(verticalArrangement = Arrangement.spacedBy(4.dp)) { Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground); if (subtitle != null) Text(subtitle, color = Muted, fontSize = 14.sp) } }
        item { Column(verticalArrangement = Arrangement.spacedBy(14.dp), content = content) }
    }
}

@Composable private fun CardBox(surface: Color, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().shadow(3.dp, RoundedCornerShape(23.dp)).background(surface.copy(alpha = .97f), RoundedCornerShape(23.dp)).padding(17.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
}

@Composable private fun SunAvatar(size: Int = 76) {
    Box(Modifier.size(size.dp).background(Brush.radialGradient(listOf(Color(0xFFFFF4C8), Sun, Gold)), CircleShape), Alignment.Center) {
        Icon(Icons.Rounded.WbSunny, "YELLOW", tint = Color.White, modifier = Modifier.size((size * .52).dp))
    }
}

@Composable private fun HomeScreen(surface: Color, ink: Color, xp: Int, done: Boolean, done2: Boolean, toggle1: () -> Unit, toggle2: () -> Unit, openPractices: () -> Unit) {
    val count = (if (done) 1 else 0) + (if (done2) 1 else 0)
    Page("Твой новый день ☀️", "Маленькие шаги складываются в большие перемены") {
        CardBox(surface) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SunAvatar(); Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("YELLOW", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ink)
                    Text("Я рядом. Не нужно менять всё сразу — выберем один следующий шаг.", color = Muted, fontSize = 13.sp)
                }
            }
        }
        CardBox(surface) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Прогресс сегодня", fontWeight = FontWeight.SemiBold, color = ink); Text("$count / 2", color = Gold, fontWeight = FontWeight.Bold) }
            LinearProgressIndicator({ count / 2f }, Modifier.fillMaxWidth().height(9.dp), color = Gold, trackColor = Cream)
            Text("${xp} XP · ${levelName(xp)}", color = Muted, fontSize = 12.sp)
        }
        CardBox(surface) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("Практики на сегодня", fontWeight = FontWeight.SemiBold, color = ink); TextButton(onClick = openPractices) { Text("Все") } }
            TaskLine("Утренняя настройка", "5 минут · Осознанность", done, toggle1)
            HorizontalDivider(color = Cream)
            TaskLine("Один шаг к мечте", "10 минут · Цели", done2, toggle2)
        }
        CardBox(surface) {
            Text("Мысль дня", fontWeight = FontWeight.SemiBold, color = ink)
            Text("«Не обязательно видеть всю лестницу. Достаточно сделать первую ступеньку». ", color = Muted)
        }
    }
}

@Composable private fun TaskLine(title: String, detail: String, done: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) { Text(title, fontWeight = FontWeight.Medium); Text(detail, color = Muted, fontSize = 12.sp) }
        Checkbox(done, { onClick() }, colors = CheckboxDefaults.colors(checkedColor = Gold))
    }
}

@Composable private fun PracticesScreen(surface: Color, ink: Color, store: LocalStore) {
    var selectedProgram by remember { mutableStateOf(store.string("program", "")) }
    var customTitle by remember { mutableStateOf("") }
    var showCustom by remember { mutableStateOf(false) }
    Page("Практики", "Программы на 7, 21 и 30 дней") {
        listOf(Triple("Новый старт", "7 дней", "Мягко вернуться к себе и создать первые опоры"), Triple("Новая версия себя", "21 день", "Дисциплина, уверенность и устойчивые привычки"), Triple("Трансформация", "30 дней", "Системная работа над важными направлениями" )).forEach { (name, length, desc) ->
            CardBox(surface) {
                Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(name, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ink); Text(length, color = Gold, fontWeight = FontWeight.SemiBold) }; if (selectedProgram == name) Icon(Icons.Rounded.CheckCircle, null, tint = Gold) }
                Text(desc, color = Muted, fontSize = 13.sp)
                Button(onClick = { selectedProgram = name; store.putString("program", name) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Sun, contentColor = Ink)) { Text(if (selectedProgram == name) "Программа выбрана" else "Выбрать программу") }
            }
        }
        CardBox(surface) {
            Text("Моя программа", fontWeight = FontWeight.SemiBold, color = ink)
            Text(if (selectedProgram.isBlank()) "Пока не выбрана" else "Активная программа: $selectedProgram", color = Muted, fontSize = 13.sp)
            val custom = store.string("custom_practice")
            if (custom.isNotBlank()) Text("Своя практика: $custom", color = Gold, fontSize = 13.sp)
            OutlinedButton(onClick = { showCustom = true }) { Icon(Icons.Rounded.Add, null); Text("Создать свою практику") }
        }
    }
    if (showCustom) AlertDialog(onDismissRequest = { showCustom = false }, title = { Text("Новая практика") }, text = { OutlinedTextField(customTitle, { customTitle = it }, label = { Text("Название") }, singleLine = true) }, confirmButton = { TextButton(onClick = { if (customTitle.isNotBlank()) { store.putString("custom_practice", customTitle.trim()); showCustom = false; customTitle = "" } }) { Text("Сохранить") } }, dismissButton = { TextButton(onClick = { showCustom = false }) { Text("Отмена") } })
}

@Composable private fun NotebookScreen(surface: Color, ink: Color, notes: List<Note>, onNotes: (List<Note>) -> Unit) {
    var draft by remember { mutableStateOf("") }
    val date = remember { SimpleDateFormat("dd.MM.yyyy · HH:mm", Locale.getDefault()) }
    Page("Блокнот", "Личное пространство для мыслей и благодарности") {
        CardBox(surface) {
            Text("Новая запись", fontWeight = FontWeight.SemiBold, color = ink)
            OutlinedTextField(draft, { draft = it }, Modifier.fillMaxWidth(), minLines = 4, placeholder = { Text("Что сегодня важно для тебя?") })
            Button(onClick = { onNotes(listOf(Note(draft.trim(), date.format(Date()))) + notes); draft = "" }, enabled = draft.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = Sun, contentColor = Ink), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Save, null); Spacer(Modifier.width(8.dp)); Text("Сохранить запись") }
            Text("Записи сохраняются локально на этом устройстве.", color = Muted, fontSize = 11.sp)
        }
        CardBox(surface) { Text("Вопрос дня", fontWeight = FontWeight.SemiBold, color = ink); Text("За что ты сегодня благодарен? Какой небольшой шаг приблизил тебя к мечте?", color = Muted) }
        if (notes.isNotEmpty()) {
            Text("Твои записи", fontWeight = FontWeight.Bold, color = ink)
            notes.forEachIndexed { index, note -> CardBox(surface) { Text(note.date, color = Gold, fontSize = 11.sp); Text(note.text, color = ink); TextButton(onClick = { onNotes(notes.filterIndexed { i, _ -> i != index }) }) { Text("Удалить запись", color = Muted) } } }
        }
    }
}

@Composable private fun DreamsScreen(surface: Color, ink: Color, dreams: List<Dream>, onDreams: (List<Dream>) -> Unit) {
    var title by remember { mutableStateOf("") }
    var detail by remember { mutableStateOf("") }
    var showAdd by remember { mutableStateOf(false) }
    Page("Мои мечты", "Превращай желания в цели и конкретные шаги") {
        CardBox(surface) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Gold, modifier = Modifier.size(30.dp))
            Text("Доска визуализации", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = ink)
            Text("Собирай свои мечты, описывай желаемый результат и отмечай продвижение.", color = Muted, fontSize = 13.sp)
            Button(onClick = { showAdd = true }, colors = ButtonDefaults.buttonColors(containerColor = Sun, contentColor = Ink)) { Icon(Icons.Rounded.Add, null); Text("Добавить мечту") }
        }
        if (dreams.isEmpty()) CardBox(surface) { Text("Здесь появятся твои мечты", fontWeight = FontWeight.SemiBold, color = ink); Text("Начни с одной — самой важной на данный момент.", color = Muted, fontSize = 13.sp) }
        dreams.forEachIndexed { index, dream -> CardBox(surface) {
            Text(dream.title, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = ink)
            if (dream.detail.isNotBlank()) Text(dream.detail, color = Muted, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Прогресс", color = Muted, fontSize = 12.sp); Text("${dream.progress}%", color = Gold, fontWeight = FontWeight.Bold) }
            LinearProgressIndicator({ dream.progress / 100f }, Modifier.fillMaxWidth(), color = Gold, trackColor = Cream)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { onDreams(dreams.mapIndexed { i, d -> if (i == index) d.copy(progress = (d.progress + 10).coerceAtMost(100)) else d }) }) { Text("+10% прогресса") }
                TextButton(onClick = { onDreams(dreams.filterIndexed { i, _ -> i != index }) }) { Text("Удалить", color = Muted) }
            }
        } }
    }
    if (showAdd) AlertDialog(onDismissRequest = { showAdd = false }, title = { Text("Добавить мечту") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(title, { title = it }, label = { Text("Название мечты") }, singleLine = true); OutlinedTextField(detail, { detail = it }, label = { Text("Почему это важно?" ) }, minLines = 2) } }, confirmButton = { TextButton(onClick = { if (title.isNotBlank()) { onDreams(dreams + Dream(title.trim(), detail.trim(), 0)); title = ""; detail = ""; showAdd = false } }) { Text("Добавить") } }, dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Отмена") } })
}

@Composable private fun ProfileScreen(surface: Color, ink: Color, xp: Int, noteCount: Int, dreamCount: Int, store: LocalStore) {
    var reminders by remember { mutableStateOf(store.bool("reminders", true)) }
    var sound by remember { mutableStateOf(store.bool("sounds", false)) }
    var language by remember { mutableStateOf(store.string("language", "Русский")) }
    Page("Профиль", "Твой путь, достижения и настройки") {
        CardBox(surface) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) { SunAvatar(62); Column { Text("Мой путь", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ink); Text("${levelName(xp)} · $xp XP", color = Gold, fontSize = 13.sp) } }
            val next = ((xp / 100) + 1) * 100
            LinearProgressIndicator({ (xp % 100) / 100f }, Modifier.fillMaxWidth(), color = Gold, trackColor = Cream)
            Text("До следующего уровня: ${next - xp} XP", color = Muted, fontSize = 12.sp)
        }
        CardBox(surface) { Text("Твоя статистика", fontWeight = FontWeight.SemiBold, color = ink); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { Stat("$noteCount", "записей"); Stat("$dreamCount", "мечтаний"); Stat("$xp", "XP") } }
        CardBox(surface) {
            Text("Настройки", fontWeight = FontWeight.SemiBold, color = ink)
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Напоминания", Modifier.weight(1f)); Switch(reminders, { reminders = it; store.putBool("reminders", it) }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Звуки интерфейса", Modifier.weight(1f)); Switch(sound, { sound = it; store.putBool("sounds", it) }) }
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Язык", Modifier.weight(1f)); TextButton(onClick = { language = if (language == "Русский") "English" else "Русский"; store.putString("language", language) }) { Text(language) } }
            Text("Тема оформления следует настройкам устройства.", color = Muted, fontSize = 11.sp)
        }
        CardBox(surface) { Text("YELLOW", fontWeight = FontWeight.Bold, color = ink); Text("Мягкий, спокойный наставник. Я помогу тебе замечать прогресс и выбирать следующий шаг.", color = Muted, fontSize = 13.sp); Text("Важно: облачный ИИ, голосовые диалоги и синхронизация пока не подключены в этой сборке.", color = Muted, fontSize = 11.sp) }
    }
}

@Composable private fun Stat(value: String, label: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Gold); Text(label, fontSize = 11.sp, color = Muted) } }
private fun levelName(xp: Int): String = when (xp / 100) { 0 -> "Начинающий"; 1 -> "Искатель"; 2 -> "Ученик"; 3 -> "Созидатель"; 4 -> "Стратег"; 5 -> "Мастер дисциплины"; else -> "Архитектор своей жизни" }
