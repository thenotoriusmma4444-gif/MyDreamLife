# My Dream Life — Android prototype

An Android app prototype built with Kotlin and Jetpack Compose. This iteration adds local persistence using Android SharedPreferences.

## Included in this build
- Five-section navigation: Home, Practices, Notebook, Dreams, Profile.
- Light/dark colors follow the device system theme.
- YELLOW companion introduction and daily progress.
- Daily practice checkboxes and local XP counter.
- 7-, 21- and 30-day program selection, plus custom-practice title entry.
- Notebook entries with timestamps, local save and delete.
- Dream cards with descriptions, progress updates and delete.
- Profile statistics, level progression, reminder/sound preference toggles and language selector state.

## Honest implementation status
This is a functional local-first prototype, not yet a production release. Data currently stays on the device and is not encrypted by this prototype. The reminders toggle stores a preference but scheduled notifications are not wired yet. The language selector stores the selected value but does not yet translate the UI. Real cloud AI/voice, Google sign-in and sync, encrypted email backups, photo uploads, notification scheduling, tests and release signing remain to be implemented and verified.

## Build
Open this folder in Android Studio, use JDK 17 and Android SDK 35, sync Gradle, then build the `app` debug APK or run on a device. `applicationId`: `com.mydreamlife.app`.

## Build APK in GitHub Actions (no Android Studio required locally)
1. Upload this project folder to a new GitHub repository.
2. Open the repository's **Actions** tab and enable Actions if prompted.
3. Run **Build My Dream Life APK** using **Run workflow** (or push to `main`).
4. When the workflow completes, open the run and download the `my-dream-life-debug-apk` artifact.

This workflow creates a debug APK for testing. It is not a Play Store release-signed APK.
